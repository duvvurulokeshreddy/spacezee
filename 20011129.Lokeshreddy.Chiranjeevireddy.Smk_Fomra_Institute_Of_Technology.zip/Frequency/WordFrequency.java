import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class WordFrequency {
    public static void main(String[] args) {
        String inputFile = "input.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            Map<String, Integer> wordFrequencyMap = new HashMap<>();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    word = word.toLowerCase();
                    wordFrequencyMap.put(word, wordFrequencyMap.getOrDefault(word, 0) + 1);
                }
            }

            for (Map.Entry<String, Integer> entry : wordFrequencyMap.entrySet()) {
                String word = entry.getKey();
                int frequency = entry.getValue();
                System.out.println(word + ": " + frequency);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
